Code and data repository for: "Accelerating onset of flash droughts induced by the joint influence of soil moisture depletion and atmospheric aridity" Qing et al. 2021

Current preprint: https://assets.researchsquare.com/files/rs-267288/v1_covered.pdf?c=1631857995

Contents


1.Caculation

Codes for main analysises based on different datasets.


2.Result

Main results of the codes in Calculation folder.