####For 1-pentad onset
library(ncdf4)
nc=nc_open("F:/Flah-drought-SM/FD/Gleam/SMroot_2000-2020_Noah_v3.5a-map-pen.nc")
nc1=nc_open("F:/Flah-drought-SM/FD/Gleam/SMroot_2000-2020_Noah_v3.5a-map-pen-40th.nc")
nc2=nc_open("F:/Flah-drought-SM/FD/Gleam/SMroot_2000-2020_Noah_v3.5a-map-pen-20th.nc")
lon=ncvar_get(nc,"lon")
lat=ncvar_get(nc,"lat")
time=ncvar_get(nc,"time")
SM=ncvar_get(nc,"SMroot")
SM40=ncvar_get(nc1,"SM40")
SM20=ncvar_get(nc2,"SM20")

lonlat <- as.matrix(expand.grid(lon,lat))
SM_vet=as.vector(SM)
SM_40_vet=as.vector(SM40)
SM_20_vet=as.vector(SM20)
nlon=dim(lon)
nlat=dim(lat)
ntime=dim(time)

SM_mat <- matrix(SM_vet, nrow=54000, ncol=ntime)
SM_40_mat <- matrix(SM_40_vet, nrow=54000, ncol=ntime)
SM_20_mat <- matrix(SM_20_vet, nrow=54000, ncol=ntime)
data <- data.frame(cbind(lonlat,SM_mat))
data=na.omit(data)
data2=data

SM_40_mat1<- data.frame(cbind(lonlat,SM_40_mat))
SM_20_mat1<- data.frame(cbind(lonlat,SM_20_mat))
SM_mat_perc_40_all=na.omit(SM_40_mat1)
SM_mat_perc_20_all=na.omit(SM_20_mat1)


require(dplyr)


colnames(data2)[1:2]=c("lon","lat")
colnames(SM_mat_perc_40_all)[1:2]=c("lon","lat")
colnames(SM_mat_perc_20_all)[1:2]=c("lon","lat")

data22=data2[,3:1535]

nrrow=dim(data22)[1]


SM_mat_perc=matrix(NA, nrow=nrrow, ncol=1533)
for(i in 1:nrrow){
temp=data.frame(x=t(data[i,3:1535]))
colnames(temp)=c("x")
perc.rank=function(x) trunc(rank(x))/length(x)
out <- within(temp, xr <- perc.rank(x))
SM_mat_perc[i,]=out[,2]*100
}







b=matrix(NA, nrow=nrrow, ncol=1533)
for(j in 1:nrrow){
 for(i in 1:1530){
if(data22[j,i]>=SM_mat_perc_40_all[j,i]&&(SM_mat_perc[j,i+1]-SM_mat_perc[i])<=-5&&data22[j,i+1]<=SM_mat_perc_20_all[j,i+1]&&data22[j,i+2]<SM_mat_perc_20_all[j,i+2]&&data22[j,i+3]<SM_mat_perc_20_all[j,i+3])
 b[j,i]=1
}
}



b[is.na(b)]=0

library(zoo)
bb=matrix(NA, nrow=nrrow, ncol=21)

 for(j in 1:nrrow){

bb[j,]=rollapply(b[j,],73,sum,by=73)

}


write.csv(bb,file="F:/Flah-drought-SM/double-check/Noah-frequency-1-pentads-year.nc")






