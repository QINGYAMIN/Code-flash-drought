
library(ncdf4)
nc=nc_open("F:/Flah-drought-SM/FD/ENSMEAN-pr-1985-2014-new-map-yearsum-mean-mapp.nc")
lon=ncvar_get(nc,"lon")
lat=ncvar_get(nc,"lat")
time=ncvar_get(nc,"time")
SM=ncvar_get(nc,"pr")
lonlat <- as.matrix(expand.grid(lon,lat))
SM_vet=as.vector(SM)
nlon=dim(lon)
nlat=dim(lat)
ntime=dim(time)

SM_mat <- matrix(SM_vet, nrow=54000, ncol=ntime)

data <- data.frame(cbind(lonlat,SM_mat))
data=na.omit(data)
data1=data


nc=nc_open("F:/Flah-drought-SM/FD/Gleam/SMroot_2000-2020_GLEAM_v3.5a-map-pen.nc")
lon=ncvar_get(nc,"lon")
lat=ncvar_get(nc,"lat")
time=ncvar_get(nc,"time")
SM=ncvar_get(nc,"SMroot")
lonlat <- as.matrix(expand.grid(lon,lat))
SM_vet=as.vector(SM)
nlon=dim(lon)
nlat=dim(lat)
ntime=dim(time)

SM_mat <- matrix(SM_vet, nrow=54000, ncol=ntime)

data <- data.frame(cbind(lonlat,SM_mat))
data=na.omit(data)
data2=data


require(dplyr)
colnames(data1)[1:2]=c("lon","lat")

colnames(data2)[1:2]=c("lon","lat")

data1=semi_join(data1,data2,by=c("lon","lat"))
data2=semi_join(data2,data1,by=c("lon","lat"))

data22=data2[,3:1535]


SM_mat_perc=matrix(NA, nrow=10866, ncol=1533)

for(i in 1:10866){
temp=data.frame(x=t(data[i,3:1535]))
colnames(temp)=c("x")
perc.rank=function(x) trunc(rank(x))/length(x)
out <- within(temp, xr <- perc.rank(x))
SM_mat_perc[i,]=out[,2]*100
}


SM_mat_perc_20=matrix(NA, nrow=10866, ncol=73)

for(i in 1:10866){
for(j in 3:75){
list=seq(j,1535,by=73)
temp=data.frame(x=t(data2[i,list]))
percen=quantile(temp[,1], c(.20))
SM_mat_perc_20[i,j-2]=percen
}
}

SM_mat_perc_20_all = cbind(SM_mat_perc_20,SM_mat_perc_20,SM_mat_perc_20,SM_mat_perc_20,SM_mat_perc_20,SM_mat_perc_20,SM_mat_perc_20,SM_mat_perc_20,SM_mat_perc_20,SM_mat_perc_20,SM_mat_perc_20,SM_mat_perc_20,SM_mat_perc_20,SM_mat_perc_20,SM_mat_perc_20,SM_mat_perc_20,SM_mat_perc_20,SM_mat_perc_20,SM_mat_perc_20,SM_mat_perc_20,SM_mat_perc_20)



SM_mat_perc_40=matrix(NA, nrow=10866, ncol=73)

for(i in 1:10866){
for(j in 3:75){
list=seq(j,1535,by=73)
temp=data.frame(x=t(data2[i,list]))
percen=quantile(temp[,1], c(.40))
SM_mat_perc_40[i,j-2]=percen
}
}

SM_mat_perc_40_all = cbind(SM_mat_perc_40,SM_mat_perc_40,SM_mat_perc_40,SM_mat_perc_40,SM_mat_perc_40,SM_mat_perc_40,SM_mat_perc_40,SM_mat_perc_40,SM_mat_perc_40,SM_mat_perc_40,SM_mat_perc_40,SM_mat_perc_40,SM_mat_perc_40,SM_mat_perc_40,SM_mat_perc_40,SM_mat_perc_40,SM_mat_perc_40,SM_mat_perc_40,SM_mat_perc_40,SM_mat_perc_40,SM_mat_perc_40)






##4-pentads

b=matrix(NA, nrow=10866, ncol=1533)
for(j in 1:10866){
 for(i in 1:1528){
if(data22[j,i]>=SM_mat_perc_40_all[j,i]&&(SM_mat_perc[j,i+1]-SM_mat_perc[j,i])<=-5&&data22[j,i+1]>SM_mat_perc_20_all[j,i+1]&&(SM_mat_perc[j,i+2]-SM_mat_perc[j,i+1])<=-5&&data22[j,i+2]>SM_mat_perc_20_all[j,i+2]&&(SM_mat_perc[j,i+3]-SM_mat_perc[j,i+2])<=-5&&data22[j,i+3]>SM_mat_perc_20_all[j,i+3]&&(SM_mat_perc[j,i+4]-SM_mat_perc[j,i+3])<=-5&&data22[j,i+4]<=SM_mat_perc_20_all[j,i+4]&&data22[j,i+5]<SM_mat_perc_20_all[j,i+5])

 b[j,i]=1


}
}


b[is.na(b)]=0

library(zoo)
bb=matrix(NA, nrow=10866, ncol=21)

 for(j in 1:10866){

bb[j,]=rollapply(b[j,],73,sum,by=73)

}



data_SM_mat_perc=data.frame(cbind(data2[,1:2],bb))
 
 fillvalue <- 1e32
 frequency_array <- array(fillvalue, dim=c(nlon,nlat,21))
 
 ptm <- proc.time() # time the loop
 nobs <- dim(data_SM_mat_perc)[1]
 for(i in 1:nobs) {
   
   j <- which.min(abs(lon-data_SM_mat_perc$lon[i]))
   k <- which.min(abs(lat-data_SM_mat_perc$lat[i]))
   frequency_array[j,k,1:21] <- as.matrix(data_SM_mat_perc[i,3:(23)])
 }
 proc.time() - ptm # how long?
 
 
 londim <- ncdim_def("lon","degrees_east",as.double(lon))
 latdim <- ncdim_def("lat","degrees_north",as.double(lat))
 timedim <- ncdim_def("time","time",as.double(time[1:21]))
 dlname <- "frequency each event"
 frequency <- ncvar_def("FOC","numder",list(londim,latdim,timedim),fillvalue,dlname,prec="single")
 ncout <- nc_create("F:/Flah-drought-SM/FD/diffrent-pentads/GLEAM-frequency-4-pentads-year.nc",list(frequency),force_v4=TRUE)
 ncvar_put(ncout,frequency,frequency_array)
nc_close(ncout)





